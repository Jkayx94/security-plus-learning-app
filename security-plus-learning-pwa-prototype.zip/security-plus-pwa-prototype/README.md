# Security+ SY0-701 Mastery PWA — Objective 1.1 Prototype

Android-first installable Progressive Web App covering only:

- `UNIT-1.1-01` — Categories
- `UNIT-1.1-02` — Control types

The app uses React, TypeScript, Vite, local browser storage, a web-app manifest and a service worker. It requires no OpenAI API key.

## Local run

1. Install Node.js 20 or later.
2. Extract this ZIP.
3. Open a terminal in the extracted `security-plus-pwa-prototype` folder.
4. Run:

```bash
npm install
npm run validate
npm run dev -- --host
```

5. Open the URL printed by Vite. To test on an Android phone on the same network, use the printed LAN address. Some browsers require HTTPS for service-worker installation outside `localhost`; use the production deployment method below for a reliable phone install.

## Production build

```bash
npm install
npm run validate
npm run build
npm run preview -- --host
```

The production files are created in `dist/`. Deploy the contents of `dist/` to any HTTPS static host, such as Azure Static Web Apps, Cloudflare Pages, GitHub Pages, Netlify or Vercel.

## Install on Android

1. Deploy the `dist/` folder to an HTTPS website.
2. Open the site in Chrome or Samsung Internet.
3. In Chrome, open the three-dot menu and select **Add to Home screen** or **Install app**.
4. In Samsung Internet, open the menu and select **Add page to**, then **Home screen**.
5. Launch the installed app once while online so the service worker can cache the application. It can then reopen offline.

## Included functions

- Home actions: Continue, 2/5/10-minute sessions, Learn, Review and Dashboard.
- Step-by-step lessons with resume positions, checkpoints and memory cues.
- One-question-at-a-time practice with four permitted responses: three progressively stronger hints, then a final guided response.
- Level-3 answer text is shown only after the third incorrect response and before the final response.
- Local progress, study events, misconception tags and next-review dates.
- JSON progress import/export and confirmed reset.
- Dashboard for concept status, mastery, first-attempt accuracy, hint dependence, misconceptions, reviews and unit progress.
- Readable validation errors instead of a blank screen.
- Offline shell caching and installable manifest.

## Data and source handling

The app contains a prototype-scoped copy of the approved Objective 1.1 structures and content under `src/data/`. Runtime progress is written to browser local storage and does not modify bundled source JSON files.

## Known prototype limitations

- Only the two approved Objective 1.1 units are included.
- Progress remains on one browser/device unless manually exported and imported.
- No account, cloud sync, multi-device merge or server-side backup.
- The scheduler is a simplified deterministic implementation of the supplied spaced-repetition rules, not the full future engine.
- Session duration controls question count rather than enforcing a hard countdown.
- PBQ-style drag-and-drop interactions are not included; questions use touch-friendly answer buttons.
- Service-worker caching is intentionally simple and does not include update-notification UI.
- SVG placeholder icons are used.
- Confidence is optional; unanswered confidence is recorded as blank.
- Lesson checkpoints provide self-check feedback rather than scored mastery evidence.
